Mr. Sajches Pixel Art Quiz Generator(Ver 2.0)

Made by - Alfredo

To use this program, click the EXE file named quizMaker.exe

Whats New:
-Ability to choose starting cell for questions/answers.
-Some bug fixes

In this program you can
-Name the Google Sheet
-Select a custom image
-Create the quiz within the program
-OR Import questions and answers via a .csv file (This is recommended)
-The pixels are randomly assigned to the answer
-Image is automatically stretched to fit the screen.

STEPS:
1.Enter name of the Google Sheet (if the name is already used, the sheet with the name will be replaced)
2.Enter the filepath of the image you will use. Its easier to put the image in the same folder as the program and then just enter the file name.
3.Select how you will make the quiz. You can create one within the program, or you can import one using a .csv file (.csv files are reccomended so you can save the questions and answers)
4.Wait for quiz to be created (Larger images will take longer)
5.Select starting cell.
6.Enter the email of the drive you want the Google Sheet sent to.
7.Do the hokey pokey

NOTES:
-When creating a quiz within the program, please dont enter any spaces before or after the colon
-its recommended you keep all text lowercase (the quiz is case sensitive)
-It is recommended you use images no bigger than 300x300
-Smaller images are ideal, but you can use any size image you want
-BE CAREFUL WHEN TYPING EMAIL! If the email exists, it can not be returned (as far as I know)

This program was built in python. It is built to create a Google Sheet that can then be shared with an email.
The sheet is created in a bot email, and is then sent to the user. Within the sheet, you can input answers to questions.
The more questions you answer correctly, the more pixels of a mysterious image appear. Once all questions are answered
correctly, the image is fully visible.
